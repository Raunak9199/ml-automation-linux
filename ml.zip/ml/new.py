import os
import tkinter as tk
from tkinter import *
from tkinter.filedialog import askopenfilename
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, r2_score
from sklearn.impute import SimpleImputer
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

from sklearn.neighbors import KNeighborsClassifier

root = Tk()
root.geometry('800x750')


class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        self.create_widgets()

    def create_widgets(self):
        # create the model selection frame
        self.model_selection_frame = tk.Frame(self)
        self.model_selection_frame.pack(side="top")

        tk.Label(self.model_selection_frame, text="Choose the model based on the type of problem", font="System").grid(row=0, column=1)

        tk.Label(self.model_selection_frame, text="Regression", font="System").grid(row=1, column=0)
        tk.Label(self.model_selection_frame, text="Clustering", font="System").grid(row=1, column=1)
        tk.Label(self.model_selection_frame, text="Classification", font="System").grid(row=1, column=2)

        tk.Button(self.model_selection_frame, text='K-Neighbors', activebackground="black", command=self.KNC, activeforeground="white").grid(row=2, column=2)
        tk.Button(self.model_selection_frame, text='K-Means', command=self.Kmeans, activebackground="black", activeforeground="white").grid(row=2, column=1)
        tk.Button(self.model_selection_frame, text='Multinomial Naive-Bayes', activebackground="black", command=self.NBCls, activeforeground="white").grid(row=2, column=2)
        tk.Button(self.model_selection_frame, text='SVM Classifier', activebackground="black", command=self.SVMCls, activeforeground="white").grid(row=2, column=2)
        tk.Button(self.model_selection_frame, text='SVM Regressor', activebackground="black", command=self.SVMReg, activeforeground="white").grid(row=2, column=0)
        tk.Button(self.model_selection_frame, text='Lasso Regression', activebackground="black", command=self.Lasso, activeforeground="white").grid(row=2, column=0)
        tk.Button(self.model_selection_frame, text='Ridge Regression', activebackground="black", command=self.Ridge, activeforeground="white").grid(row=2, column=0)
        tk.Button(self.model_selection_frame, text='Linear Regression', activebackground="black", command=self.LinReg, activeforeground="white").grid(row=2, column=0)
        tk.Button(self.model_selection_frame, text='Logistic Regression', activebackground="black", command=self.LogReg, activeforeground="white").grid(row=2, column=2)
        tk.Button(self.model_selection_frame, text='MLP Classifier', activebackground="black", command=self.MLPCls, activeforeground="white").grid(row=2, column=2)
        tk.Button(self.model_selection_frame, text='Decision Tree Classifier', activebackground="black", command=self.DTClf, activeforeground="white").grid(row=3, column=1)
        tk.Button(self.model_selection_frame, text='Random Forest Classifier', activebackground="black", command=self.RFClf, activeforeground="white").grid(row=3, column=2)

def NB(self):
    self.model_name = "Naive Bayes"
    self.model = GaussianNB()
    self.train_model()

def LR(self):
    self.model_name = "Logistic Regression"
    self.model = LogisticRegression()
    self.train_model()

def SVM(self):
    self.model_name = "Support Vector Machine"
    self.model = SVC()
    self.train_model()

def KNN(self):
    self.model_name = "K-Nearest Neighbors"
    self.model = KNeighborsClassifier()
    self.train_model()

def MLPCls(self):
    self.model_name = "MLP Classifier"
    self.model = MLPClassifier()
    self.train_model()

def DTClf(self):
    self.model_name = "Decision Tree Classifier"
    self.model = DecisionTreeClassifier()
    self.train_model()

def RFClf(self):
    self.model_name = "Random Forest Classifier"
    self.model = RandomForestClassifier()
    self.train_model()

def train_model(self):
    self.model.fit(self.X_train, self.y_train)
    y_pred = self.model.predict(self.X_test)
    self.accuracy = accuracy_score(self.y_test, y_pred)
    self.display_results()

def display_results(self):
    messagebox.showinfo("Results", f"Model: {self.model_name}\nAccuracy: {self.accuracy}")

root.mainloop()