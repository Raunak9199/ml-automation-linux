import csv
import tkinter as tk
from tkinter import *
from tkinter import ttk

def csv_viewer(filename):
    class CSVViewer(tk.Frame):
        def __init__(self, master=None):
            super().__init__(master)
            self.master = master
            self.tree = None
            self.headers = []
            self.data = []
            self.init_ui()

        def init_ui(self):
            self.tree = tk.ttk.Treeview(self)
            self.tree.pack(fill='both', expand=True)

            with open(filename, 'r') as f:
                csv_reader = csv.reader(f)
                self.headers = next(csv_reader)
                for row in csv_reader:
                    self.data.append(row)

            self.tree['columns'] = self.headers
            for header in self.headers:
                self.tree.column(header, width=100)
                self.tree.heading(header, text=header)

            for row in self.data:
                self.tree.insert('', 'end', values=row)
    root = tk.Tk()
    app = CSVViewer(master=root)
    app.pack(fill='both', expand=True)
    app.mainloop()
