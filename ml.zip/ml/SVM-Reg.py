import tkinter as tk
from tkinter import *
from tkinter import ttk
import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score,r2_score
from sklearn.impute import SimpleImputer
from tkinter.filedialog import askopenfilename
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

from sklearn.svm import SVR

feature_col=[]
target_col=[]


root= Tk()
root.title('Support Vector Machine - Regressor')
root.geometry('1200x750')

frame1 = tk.LabelFrame(root, text='Excel Data')
frame1.place(height=400, width=600,x=700, y=20)

# Treeview
tv1 = ttk.Treeview(frame1)
tv1.place(relheight=1, relwidth=1)

treescrollY = tk.Scrollbar(frame1,orient="vertical", command=tv1.yview)
treescrollX = tk.Scrollbar(frame1,orient="horizontal", command=tv1.xview)
tv1.configure(xscrollcommand=treescrollX.set, yscrollcommand=treescrollY.set)
treescrollX.pack(side='bottom', fill='x')
treescrollY.pack(side='right', fill='y')


def clear_data():
    tv1.delete(*tv1.get_children())
    e1.delete(0,tk.END)
    box1.delete(0,END)
    box2.delete(0,END)
    box3.delete(0,END)



def data():
    global filename
    clear_data()
    filename = askopenfilename(initialdir=r'/home/raunak/Desktop/sem8/machine learning/', title="Select file")
    try:
        global file
        file = pd.read_csv(filename)
    except ValueError:
        tk.messagebox.showerror("Error","Invalid File!!")
        return None
    except FileNotFoundError:
        tk.messagebox.showerror("Error","No such file as {filename}")
        return None
   
    e1.insert(0, filename)
    e1.config(text=filename)

    for i in file.columns:
        box1.insert(END,i)

    for i in file.columns:
        if type(file[i][0]) == np.float64 :
            file[i].fillna(file[i].mean(), inplace=True)
        elif type(file[i][0]) == np.int64 :
            file[i].fillna(file[i].median(), inplace=True)
        elif type(file[i][0]) == type(""):
            imp_ = SimpleImputer(missing_values=np.nan, strategy='mostfrequent')
            s = imp.fit_transform(file[i].values.reshape(-1, 1))
            file[i] = s

    colss=file.columns
    global X_Axis
    X_Axis = StringVar()
    X_Axis.set('X-axis')
    choose = ttk.Combobox(root, width=22, textvariable=X_Axis)
    choose['values'] = (tuple(colss))
    choose.place(x=400, y=20)

    global Y_Axis
    Y_Axis = StringVar()
    Y_Axis.set('Y-axis')
    choose = ttk.Combobox(root, width=22, textvariable=Y_Axis)

    choose['values'] = (tuple(colss))
    choose.place(x=400, y=40)
    global graphtype
    graphtype = StringVar()
    graphtype .set('Graph')
    choose = ttk.Combobox(root, width=22, textvariable=graphtype)
    choose['values'] = ('scatter','line','bar','hist','corr','pie')
    choose.place(x=400, y=60)

    tv1['column'] = list(file.columns)
    tv1['show'] = "headings"
    for column in tv1['column']:
        tv1.heading(column, text=column)
    
    df_rows = file.to_numpy().tolist()
    for row in df_rows:
        tv1.insert("", "end", values=row)


def getx():
    x_v = []
    s = box1.curselection()
    global feature_col
    for i in s:
        if i not in feature_col:
            feature_col.append((file.columns)[i])
            x_v = feature_col
    for i in x_v:
        box2.insert(END,i)


def gety():
    y_v = []
    global target_col
    s = box1.curselection()
    for j in s:
        if j not in target_col:
            target_col.append((file.columns)[j])
            y_v=target_col

    for i in y_v:
        box3.insert(END,i)



def plot():

    fig = Figure(figsize=(6,6), dpi=70)
    global X_Axis
    global Y_Axis
    global graphtype
    u=graphtype.get()

    if u=='scatter':
        plot1 = fig.add_subplot(111)
        plt.scatter(file[X_Axis.get()], file[Y_Axis.get()])
        plt.xlabel(X_Axis.get())
        plt.ylabel(Y_Axis.get())
        plt.show()

    if u=='line':
        plot1 = fig.add_subplot(111)
        plt.plot(file[X_Axis.get()], file[Y_Axis.get()])
        plt.xlabel(X_Axis.get())
        plt.ylabel(Y_Axis.get())
        plt.show()

    if u=='bar':
        plot1 = fig.add_subplot(111)
        plt.bar(file[X_Axis.get()], file[Y_Axis.get()])
        plt.xlabel(X_Axis.get())
        plt.ylabel(Y_Axis.get())
        plt.show()

    if u=='hist':
        plot1 = fig.add_subplot(111)
        plt.hist(file[X_Axis.get()],file[Y_Axis.get()])
        plt.xlabel(X_Axis.get())
        plt.ylabel(Y_Axis.get())
        plt.show()

    if u=='corr':
        plot1 = fig.add_subplot(111)
        sns.heatmap(file.corr())
        plt.show()

    if u=='pie':
        plot1 = fig.add_subplot(111)
        plt.pie(file[Y_Axis.get()].value_counts(),labels=file[Y_Axis.get()].unique())
        plt.show()



def model():

    x = file[feature_col]
    y = file[target_col]

    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=float(split.get()))

    model=SVR(epsilon=float(eps.get()),kernel=Kernal.get(),gamma=gam.get())
    model.fit(x_train,np.ravel(y_train))

    x_dummies = s.get().split(",")
    x_tests = []
    for i in x_dummies:
        x_tests.append(float(i))
    y_pred = model.predict([x_tests])

    train_accuracy = r2_score(np.ravel(y_train), model.predict(x_train))
    test_accuracy = r2_score(np.ravel(y_test), model.predict(x_test))

    Label(root, text=str(y_pred), font=('Helvetica', 10, 'bold'), bg="light blue", relief="solid").place(x=400,y=450)
    Label(root,text=f'Train accuracy : {train_accuracy}', font=('Helvetica', 10, 'bold'), bg="light blue", relief="solid").place(x=20,y=550)
    Label(root,text=f'Test accuracy  : {test_accuracy}', font=('Helvetica', 10, 'bold'), bg="light blue", relief="solid").place(x=20,y=600)



    if abs(train_accuracy - test_accuracy) > 0.1 or (train_accuracy < .6 and test_accuracy < .6):
        Label(root, text='BAD  MODEL', font=('Helvetica', 10, 'bold'), bg="red", relief="solid").place(x=300,
                                                                                                              y=550)

        if (train_accuracy > test_accuracy) and abs(train_accuracy - test_accuracy) > 0.1:
            Label(root, text='OVERFIT', font=('Helvetica', 10, 'bold'), bg="red", relief="solid").place(
                x=400,
                y=550)

        if train_accuracy < 0.6 and test_accuracy < 0.6:
            Label(root, text='UNDERFIT', font=('Helvetica', 10, 'bold'), bg="red", relief="solid").place(
                x=400,
                y=550)

    elif (train_accuracy < test_accuracy) and abs(train_accuracy - test_accuracy) > 0.1:
        Label(root, text='GOOD MODEL', font=('Helvetica', 10, 'bold'), bg="green", relief="solid").place(x=300,
                                                                                                              y=550)

    elif train_accuracy > 0.85 and test_accuracy > 0.85:
        Label(root, text='VERY GOOD MODEL', font=('Helvetica', 10, 'bold'), bg="green", relief="solid").place(
            x=300, y=550)

    return train_accuracy, test_accuracy, x_tests, y_pred


def files():
    csv = os.path.basename(filename)
    with open(r'/home/raunak/Documents/tkinter/ML-AUTOMATION-TKINTER-/summary/svm_reg.txt',"w",encoding="utf-8") as file:
        file.write(f"You have use SVM Regressor model for {csv}\n")
        file.write("\n")
        file.write(f"The columns used for features are {feature_col} and the targetted columns are {target_col}\n")
        file.write("\n")
        file.write(f"The Hyper parameters used in the model are initiated as Epsilon - {(eps.get())} , Kernel - {Kernal.get()}, Gamma - {gam.get()}\n")
        file.write("\n")
        file.write(f"The train accuracy of the model is {model()[0]} and The test accuracy of the model is are and {model()[1]}\n")
        file.write("\n")

        if model()[0] > .9 and model()[1] > .9:
            file.write("The model is Excellent")
        if abs(model()[0] - model()[1]) > .1 and (model()[0] < .6 and model()[1] < .6):
            file.write("The model is an Underfitted one")
        if model()[0] > .6 and model()[1] > .6 and abs(model()[0] - model()[1]) > .1:
            file.write(f"The model is an Overfitted one")

        file.write("\n")
        file.write(f"The User inputs were {model()[2]} and the predicted output was {model()[3]}\n")

listbox=Listbox(root,selectmode="multiple")
listbox.pack

s=StringVar()

Entry(root,text=s,width=30).place(x=250,y=450)
Label(root,font="System",text='Inputs separated by commas').place(x=20,y=450)


Label(root,font="System",text="split_size").place(x=20,y=390)
split = StringVar()
choose = ttk.Combobox(root, width = 30, textvariable = split)
choose['values'] = ('0.2','0.25','0.3')
choose.place(x=200,y=390)

Label(root,font="System",text="Epsilon").place(x=20,y=300)
Label(root,font="System",text="Kernal").place(x=20,y=330)
Label(root,font="System",text="Gamma").place(x=20,y=360)


eps=tk.StringVar()
choose=ttk.Combobox(root,width = 30, textvariable= eps)
choose['values']=(".1",".2",".3",".4")
choose.place(x=200,y=300)

Kernal=tk.StringVar()
choose=ttk.Combobox(root,width=30,textvariable= Kernal)
choose['values']=('linear','poly','rbf','sigmoid','precomputed')
choose.place(x=200,y=330)


gam =tk.StringVar()
choose=ttk.Combobox(root,width=30,textvariable= gam)
choose['values']=('scale','auto')
choose.place(x=200,y=360)


l1=Label(root, text='Select Data File')
l1.grid(row=0, column=0)
e1 = Entry(root,text='')
e1.grid(row=0, column=1)
Button(root,text='open', command=data,activeforeground="white",activebackground="black").grid(row=0, column=2)

box1 = Listbox(root,selectmode='multiple')
box1.grid(row=10, column=0)


box2 = Listbox(root)
box2.grid(row=10, column=1)
Button(root, text='Select X', command=getx,activeforeground="white",activebackground="black").grid(row=12,column=1)

box3 = Listbox(root)
box3.grid(row=10, column=2)
Button(root, text='Select Y', command=gety,activeforeground="white",activebackground="black").grid(row=12,column=2)

Button(root,text = "Plot",command = plot,activeforeground="white",activebackground="black").place(x=600, y=50)

Button(root,text="predict",command=model,activeforeground="white",activebackground="black").grid(row=12,column=3)

Button(root,text= "Summary",command=files,activeforeground="white",activebackground="black").place(x=450,y=190)

root.mainloop()




