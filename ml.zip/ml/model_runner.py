import os
import tkinter as tk
from tkinter import *
from tkinter import ttk

import subprocess, sys


root= Tk()
root.title('ML Automation')
root.geometry('800x600')
root.configure(bg="white")
clr ="#424447"

def KNC():
    os.system("python3 KNC.py")

def Kmeans():
    os.system("python3 Kmeans.py")

def NBCls():
    os.system("python3 NaiveByes.py")

def SVMCls():
    os.system("python3 SVM-Clas.py")

def SVMReg():
    os.system("python3 SVM-Reg.py")

def Lasso():
    os.system("python3 Laso-Reg.py")

def Ridge():
    os.system("python3 Ridge-Reg.py")

def LinReg():
     os.system("python3 LinearReg.py")

def LogReg():
     os.system("python3 LogisticReg.py")

def MLPCls():
     os.system("python3 MLP-Cls.py")

def DecReg():
     os.system("python3 Decision-Reg.py")

def DecCls():
     os.system("python3 Decision-Cls.py")
    
def Best_Class():
     os.system("python3 Best_Classifier.py")

def Best_Reg():
     os.system("python3 Best_Regressor.py")
    

Label(root,text="Choose your model based on the type of problem",font="System", bg=root['bg'], fg='#1b1b1c').place(x=200,y=20)
Label(root,text='___________________________________________________',font="System", bg=root['bg'], fg='#1b1b1c').place(x=194,y=40)


Label(root,text="Regression",font="System").place(x=150,y=75)
Label(root,text="Clustering",font="System").place(x=350,y=75)
Label(root,text="Classification",font="System").place(x=550,y=75)

# style = ttk.Style()
# style.configure("TButton",
#                 font=('Helvetica', 12),
#                 padding=5,
#                 background=clr,  
#                 foreground='white',    
#                 relief='raised',      
#                 borderwidth=0,
#                 bd=3,
#                 boxshadow=(10, 10, 20, 'gray'))        

# style.map("TButton",
#           foreground=[('active', 'white'), ('disabled', 'gray')],
#           background=[('active', 'black'), ('disabled', '#e0e0e0')])


Button(root,text='Linear Regression',command=LinReg, bg=clr, fg='white', bd=2).place(x=150,y=130)
Button(root,text='Ridge Regression',command=Ridge,bg=clr, fg='white',bd=2).place(x=150,y=170)
Button(root,text='Lasso Regression',command=Lasso,bg=clr, fg='white',bd=2).place(x=150,y=210)
Button(root,text='SVM Regressor',command=SVMReg,bg=clr, fg='white',bd=2).place(x=150,y=250)
Button(root,text='DecisionTree Regressor',command=DecReg,bg=clr, fg='white',bd=2).place(x=150,y=290)

Button(root,text='K-Means',command=Kmeans,bg=clr, fg='white',bd=2).place(x=350,y=130)

Button(root,text='SVM Classifier',command=SVMCls,bg=clr, fg='white',bd=2).place(x=550,y=130)
Button(root,text='MLP Classifier',command=MLPCls,bg=clr, fg='white',bd=2).place(x=550,y=170)
Button(root,text='DecisionTree Classifier',command=DecCls,bg=clr, fg='white',bd=2).place(x=550,y=210)
Button(root,text='Multinomial Naive-Bayes',command=NBCls,bg=clr, fg='white',bd=2).place(x=550,y=250)
Button(root,text='Logistic Regression',bg=clr, fg='white',bd=2,command=LogReg).place(x=550,y=290)
Button(root,text='K-Neighbors', command=KNC,bg=clr, fg='white',bd=2 ).place(x=550,y=330)

Label(root,text= "Best Classifier and Regressor  ",font="System").place(x=250,y=400)

Button(root,text='Best Classifier',command=Best_Class,bg=clr, fg='white',bd=2).place(x=250,y=440)
Button(root,text='Best Regressor',command=Best_Reg,bg=clr, fg='white',bd=2).place(x=400,y=440)

root.mainloop()
